package com.example.bmtc;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView textView = (TextView) findViewById(R.id.textView);
        textView.setText("");
        EditText simpleEditText = (EditText) findViewById(R.id.textView2);
        simpleEditText.setHint("Username");//display the hin
        EditText simpleEditText1 = (EditText) findViewById(R.id.textView3);
        simpleEditText1.setHint("Password");//display the hin
        final Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
            }
        });
        final Button button1 = findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
            }
        });
        ImageView iv = new ImageView(getApplicationContext());

        // Set an image for ImageView
        iv.setImageDrawable(getDrawable(R.drawable.facebook));

        // Create layout parameters for ImageView
        ActionBar.LayoutParams lp = new ActionBar.LayoutParams(ActionBar.LayoutParams.WRAP_CONTENT, ActionBar.LayoutParams.WRAP_CONTENT);



        // Add layout parameters to ImageView
        iv.setLayoutParams(lp);




    }
}
